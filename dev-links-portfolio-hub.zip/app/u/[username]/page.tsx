import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { ProfileClient } from "@/components/profile/profile-client";

interface ProfilePageProps {
  params: Promise<{ username: string }>;
}

export async function generateMetadata({ params }: ProfilePageProps) {
  const { username } = await params;
  const supabase = await createClient();
  
  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, bio")
    .eq("username", username)
    .single();

  if (!profile) {
    return { title: "Profile Not Found | DevLinks" };
  }

  return {
    title: `${profile.display_name || username} | DevLinks`,
    description: profile.bio || `Check out ${profile.display_name || username}'s developer portfolio`,
  };
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { username } = await params;
  const supabase = await createClient();

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("username", username)
    .single();

  if (!profile) {
    notFound();
  }

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .eq("user_id", profile.id)
    .order("created_at", { ascending: false });

  // Fetch GitHub stats if username is provided
  let githubStats = null;
  if (profile.github_username) {
    try {
      const response = await fetch(`https://api.github.com/users/${profile.github_username}`, {
        headers: {
          "Accept": "application/vnd.github.v3+json",
        },
        next: { revalidate: 3600 }, // Cache for 1 hour
      });
      if (response.ok) {
        githubStats = await response.json();
      }
    } catch {
      // Silently fail if GitHub API is unavailable
    }
  }

  return (
    <ProfileClient 
      profile={profile} 
      projects={projects || []}
      githubStats={githubStats}
    />
  );
}
