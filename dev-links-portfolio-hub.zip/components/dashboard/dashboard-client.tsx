"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Profile, Project } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ProjectDialog } from "./project-dialog";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface DashboardClientProps {
  initialProfile: Profile | null;
  initialProjects: Project[];
  userId: string;
}

export function DashboardClient({ initialProfile, initialProjects, userId }: DashboardClientProps) {
  const [profile, setProfile] = useState<Profile | null>(initialProfile);
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const router = useRouter();
  const supabase = createClient();

  async function handleProfileUpdate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);

    const formData = new FormData(e.currentTarget);
    const updates = {
      display_name: formData.get("display_name") as string,
      bio: formData.get("bio") as string,
      avatar_url: formData.get("avatar_url") as string,
      github_username: formData.get("github_username") as string,
      twitter_url: formData.get("twitter_url") as string,
      linkedin_url: formData.get("linkedin_url") as string,
      website_url: formData.get("website_url") as string,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", userId)
      .select()
      .single();

    if (!error && data) {
      setProfile(data);
    }
    setSaving(false);
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  function handleEditProject(project: Project) {
    setEditingProject(project);
    setDialogOpen(true);
  }

  async function handleDeleteProject(projectId: string) {
    const { error } = await supabase
      .from("projects")
      .delete()
      .eq("id", projectId);

    if (!error) {
      setProjects(projects.filter(p => p.id !== projectId));
    }
  }

  function handleProjectSaved(project: Project) {
    if (editingProject) {
      setProjects(projects.map(p => p.id === project.id ? project : p));
    } else {
      setProjects([project, ...projects]);
    }
    setEditingProject(null);
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-card/30 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
            DevLinks
          </Link>
          <div className="flex items-center gap-4">
            {profile && (
              <Link 
                href={`/u/${profile.username}`}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                View Public Profile
              </Link>
            )}
            <Button variant="ghost" onClick={handleSignOut} className="text-muted-foreground hover:text-foreground">
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Manage your profile and showcase your projects</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="bg-card/50 border border-border/50">
            <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500/20 data-[state=active]:to-emerald-500/20">
              Profile
            </TabsTrigger>
            <TabsTrigger value="projects" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500/20 data-[state=active]:to-emerald-500/20">
              Projects
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Profile Settings</CardTitle>
                <CardDescription>Update your public profile information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileUpdate} className="space-y-6">
                  <div className="flex items-center gap-6">
                    <Avatar className="w-20 h-20 ring-2 ring-border">
                      <AvatarImage src={profile?.avatar_url || ""} />
                      <AvatarFallback className="text-2xl bg-gradient-to-br from-cyan-500 to-emerald-500 text-white">
                        {profile?.display_name?.[0] || profile?.username?.[0] || "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Label htmlFor="avatar_url">Avatar URL</Label>
                      <Input
                        id="avatar_url"
                        name="avatar_url"
                        type="url"
                        placeholder="https://example.com/avatar.jpg"
                        defaultValue={profile?.avatar_url || ""}
                        className="bg-background/50"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="display_name">Display Name</Label>
                      <Input
                        id="display_name"
                        name="display_name"
                        placeholder="John Doe"
                        defaultValue={profile?.display_name || ""}
                        className="bg-background/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Username</Label>
                      <Input
                        disabled
                        value={profile?.username || ""}
                        className="bg-background/30 text-muted-foreground"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      name="bio"
                      placeholder="Tell visitors about yourself..."
                      rows={4}
                      defaultValue={profile?.bio || ""}
                      className="bg-background/50 resize-none"
                    />
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-sm font-medium text-foreground">Social Links</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="github_username">GitHub Username</Label>
                        <Input
                          id="github_username"
                          name="github_username"
                          placeholder="octocat"
                          defaultValue={profile?.github_username || ""}
                          className="bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="twitter_url">Twitter URL</Label>
                        <Input
                          id="twitter_url"
                          name="twitter_url"
                          type="url"
                          placeholder="https://twitter.com/username"
                          defaultValue={profile?.twitter_url || ""}
                          className="bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="linkedin_url">LinkedIn URL</Label>
                        <Input
                          id="linkedin_url"
                          name="linkedin_url"
                          type="url"
                          placeholder="https://linkedin.com/in/username"
                          defaultValue={profile?.linkedin_url || ""}
                          className="bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website_url">Website URL</Label>
                        <Input
                          id="website_url"
                          name="website_url"
                          type="url"
                          placeholder="https://yourwebsite.com"
                          defaultValue={profile?.website_url || ""}
                          className="bg-background/50"
                        />
                      </div>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={saving}
                    className="bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-600 hover:to-emerald-600 text-white"
                  >
                    {saving ? "Saving..." : "Save Changes"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Your Projects</h2>
                  <p className="text-sm text-muted-foreground">Showcase your best work</p>
                </div>
                <Button 
                  onClick={() => { setEditingProject(null); setDialogOpen(true); }}
                  className="bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-600 hover:to-emerald-600 text-white"
                >
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Add Project
                </Button>
              </div>

              {projects.length === 0 ? (
                <Card className="border-border/50 bg-card/50 backdrop-blur border-dashed">
                  <CardContent className="py-12 text-center">
                    <div className="mx-auto w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                      <svg className="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium text-foreground mb-1">No projects yet</h3>
                    <p className="text-muted-foreground mb-4">Add your first project to showcase your work</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {projects.map((project) => (
                    <Card key={project.id} className="border-border/50 bg-card/50 backdrop-blur group hover:border-cyan-500/30 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          {project.thumbnail_url && (
                            <img 
                              src={project.thumbnail_url} 
                              alt={project.title}
                              className="w-24 h-16 object-cover rounded-lg bg-muted"
                            />
                          )}
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-foreground truncate">{project.title}</h3>
                            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{project.description}</p>
                            {project.tech_stack && project.tech_stack.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {project.tech_stack.slice(0, 4).map((tech) => (
                                  <Badge key={tech} variant="secondary" className="text-xs bg-cyan-500/10 text-cyan-400 border-0">
                                    {tech}
                                  </Badge>
                                ))}
                                {project.tech_stack.length > 4 && (
                                  <Badge variant="secondary" className="text-xs bg-muted text-muted-foreground border-0">
                                    +{project.tech_stack.length - 4}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button variant="ghost" size="sm" onClick={() => handleEditProject(project)}>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteProject(project.id)} className="text-red-400 hover:text-red-300 hover:bg-red-400/10">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <ProjectDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        project={editingProject}
        userId={userId}
        onSaved={handleProjectSaved}
      />
    </div>
  );
}
