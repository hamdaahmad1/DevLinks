"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Project } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface ProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: Project | null;
  userId: string;
  onSaved: (project: Project) => void;
}

export function ProjectDialog({ open, onOpenChange, project, userId, onSaved }: ProjectDialogProps) {
  const [saving, setSaving] = useState(false);
  const [techInput, setTechInput] = useState("");
  const [techStack, setTechStack] = useState<string[]>(project?.tech_stack || []);
  const supabase = createClient();

  function handleOpenChange(newOpen: boolean) {
    if (!newOpen) {
      setTechStack(project?.tech_stack || []);
      setTechInput("");
    } else {
      setTechStack(project?.tech_stack || []);
    }
    onOpenChange(newOpen);
  }

  function addTech(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      const tech = techInput.trim();
      if (tech && !techStack.includes(tech)) {
        setTechStack([...techStack, tech]);
      }
      setTechInput("");
    }
  }

  function removeTech(tech: string) {
    setTechStack(techStack.filter(t => t !== tech));
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);

    const formData = new FormData(e.currentTarget);
    const projectData = {
      title: formData.get("title") as string,
      description: formData.get("description") as string,
      live_url: formData.get("live_url") as string || null,
      github_url: formData.get("github_url") as string || null,
      thumbnail_url: formData.get("thumbnail_url") as string || null,
      tech_stack: techStack,
      user_id: userId,
      updated_at: new Date().toISOString(),
    };

    if (project) {
      const { data, error } = await supabase
        .from("projects")
        .update(projectData)
        .eq("id", project.id)
        .select()
        .single();

      if (!error && data) {
        onSaved(data);
        handleOpenChange(false);
      }
    } else {
      const { data, error } = await supabase
        .from("projects")
        .insert(projectData)
        .select()
        .single();

      if (!error && data) {
        onSaved(data);
        handleOpenChange(false);
      }
    }

    setSaving(false);
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="bg-card border-border/50 sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {project ? "Edit Project" : "Add Project"}
          </DialogTitle>
          <DialogDescription>
            {project ? "Update your project details" : "Add a new project to your portfolio"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              name="title"
              placeholder="My Awesome Project"
              defaultValue={project?.title || ""}
              required
              className="bg-background/50"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              placeholder="A brief description of your project..."
              rows={3}
              defaultValue={project?.description || ""}
              className="bg-background/50 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="thumbnail_url">Thumbnail URL</Label>
            <Input
              id="thumbnail_url"
              name="thumbnail_url"
              type="url"
              placeholder="https://example.com/screenshot.png"
              defaultValue={project?.thumbnail_url || ""}
              className="bg-background/50"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="live_url">Live URL</Label>
              <Input
                id="live_url"
                name="live_url"
                type="url"
                placeholder="https://myproject.com"
                defaultValue={project?.live_url || ""}
                className="bg-background/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="github_url">GitHub URL</Label>
              <Input
                id="github_url"
                name="github_url"
                type="url"
                placeholder="https://github.com/..."
                defaultValue={project?.github_url || ""}
                className="bg-background/50"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tech_stack">Tech Stack</Label>
            <Input
              id="tech_stack"
              placeholder="Type and press Enter to add..."
              value={techInput}
              onChange={(e) => setTechInput(e.target.value)}
              onKeyDown={addTech}
              className="bg-background/50"
            />
            {techStack.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {techStack.map((tech) => (
                  <Badge 
                    key={tech} 
                    variant="secondary" 
                    className="bg-cyan-500/10 text-cyan-400 border-0 cursor-pointer hover:bg-red-500/20 hover:text-red-400 transition-colors"
                    onClick={() => removeTech(tech)}
                  >
                    {tech}
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="ghost" onClick={() => handleOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={saving}
              className="bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-600 hover:to-emerald-600 text-white"
            >
              {saving ? "Saving..." : project ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
