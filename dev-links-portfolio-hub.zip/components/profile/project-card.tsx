"use client";

import { useState, useEffect } from "react";
import { Project, ReactionCount } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { createClient } from "@/lib/supabase/client";

interface ProjectCardProps {
  project: Project;
}

function getVisitorId(): string {
  if (typeof window === "undefined") return "";
  
  let visitorId = localStorage.getItem("devlinks_visitor_id");
  if (!visitorId) {
    visitorId = crypto.randomUUID();
    localStorage.setItem("devlinks_visitor_id", visitorId);
  }
  return visitorId;
}

export function ProjectCard({ project }: ProjectCardProps) {
  const [reactions, setReactions] = useState<ReactionCount>({ fire: 0, heart: 0, clap: 0 });
  const [userReactions, setUserReactions] = useState<Set<string>>(new Set());
  const [animating, setAnimating] = useState<string | null>(null);
  const supabase = createClient();

  useEffect(() => {
    fetchReactions();
  }, [project.id]);

  async function fetchReactions() {
    const visitorId = getVisitorId();
    
    // Get reaction counts
    const { data: allReactions } = await supabase
      .from("reactions")
      .select("emoji, visitor_id")
      .eq("project_id", project.id);

    if (allReactions) {
      const counts: ReactionCount = { fire: 0, heart: 0, clap: 0 };
      const userSet = new Set<string>();
      
      allReactions.forEach((r) => {
        if (r.emoji === "fire" || r.emoji === "heart" || r.emoji === "clap") {
          counts[r.emoji]++;
          if (r.visitor_id === visitorId) {
            userSet.add(r.emoji);
          }
        }
      });
      
      setReactions(counts);
      setUserReactions(userSet);
    }
  }

  async function toggleReaction(emoji: "fire" | "heart" | "clap") {
    const visitorId = getVisitorId();
    
    setAnimating(emoji);
    setTimeout(() => setAnimating(null), 300);

    if (userReactions.has(emoji)) {
      // Remove reaction
      await supabase
        .from("reactions")
        .delete()
        .eq("project_id", project.id)
        .eq("emoji", emoji)
        .eq("visitor_id", visitorId);

      setReactions(prev => ({ ...prev, [emoji]: prev[emoji] - 1 }));
      setUserReactions(prev => {
        const newSet = new Set(prev);
        newSet.delete(emoji);
        return newSet;
      });
    } else {
      // Add reaction
      await supabase
        .from("reactions")
        .insert({
          project_id: project.id,
          emoji,
          visitor_id: visitorId,
        });

      setReactions(prev => ({ ...prev, [emoji]: prev[emoji] + 1 }));
      setUserReactions(prev => new Set(prev).add(emoji));
    }
  }

  const emojiMap = {
    fire: { icon: "🔥", label: "Fire" },
    heart: { icon: "❤️", label: "Love" },
    clap: { icon: "👏", label: "Applause" },
  };

  return (
    <Card className="group border-border/50 bg-card/50 backdrop-blur overflow-hidden hover:border-cyan-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/5 hover:-translate-y-1">
      {project.thumbnail_url && (
        <div className="aspect-video overflow-hidden bg-muted">
          <img 
            src={project.thumbnail_url} 
            alt={project.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      )}
      <CardContent className="p-5">
        <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-cyan-400 transition-colors">
          {project.title}
        </h3>
        
        {project.description && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {project.description}
          </p>
        )}

        {project.tech_stack && project.tech_stack.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {project.tech_stack.map((tech) => (
              <Badge 
                key={tech} 
                variant="secondary" 
                className="text-xs bg-cyan-500/10 text-cyan-400 border-0 px-2 py-0.5"
              >
                {tech}
              </Badge>
            ))}
          </div>
        )}

        {/* Links */}
        <div className="flex items-center gap-3 mb-4">
          {project.live_url && (
            <a
              href={project.live_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-cyan-400 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              Live
            </a>
          )}
          {project.github_url && (
            <a
              href={project.github_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-cyan-400 transition-colors"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
              </svg>
              Code
            </a>
          )}
        </div>

        {/* Reactions */}
        <div className="flex items-center gap-2 pt-3 border-t border-border/50">
          {(["fire", "heart", "clap"] as const).map((emoji) => (
            <button
              key={emoji}
              onClick={() => toggleReaction(emoji)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm transition-all duration-200 ${
                userReactions.has(emoji)
                  ? "bg-cyan-500/20 text-cyan-400"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              } ${animating === emoji ? "scale-125" : ""}`}
            >
              <span className={`transition-transform ${animating === emoji ? "animate-bounce" : ""}`}>
                {emojiMap[emoji].icon}
              </span>
              <span>{reactions[emoji]}</span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
