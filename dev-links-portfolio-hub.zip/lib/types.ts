export interface Profile {
  id: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  github_username: string | null;
  twitter_url: string | null;
  linkedin_url: string | null;
  website_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  live_url: string | null;
  github_url: string | null;
  thumbnail_url: string | null;
  tech_stack: string[];
  created_at: string;
  updated_at: string;
}

export interface Reaction {
  id: string;
  project_id: string;
  emoji: "fire" | "heart" | "clap";
  visitor_id: string;
  created_at: string;
}

export interface ReactionCount {
  fire: number;
  heart: number;
  clap: number;
}

export interface GitHubStats {
  public_repos: number;
  followers: number;
  following: number;
  avatar_url: string;
  name: string;
  bio: string;
  html_url: string;
}
